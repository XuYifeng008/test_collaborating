"""Protocol example, deliberately not a manipulation baseline."""
class Policy:
    def reset(self, instruction):
        self.steps = 0

    def act(self, observation):
        self.steps += 1
        return {'arms': {}, 'steps': 1} if self.steps == 1 else {'finish': True}

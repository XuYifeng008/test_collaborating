from lab_sdk.policy import make_policy
Policy = make_policy(__file__, 'wave2', 'franka')

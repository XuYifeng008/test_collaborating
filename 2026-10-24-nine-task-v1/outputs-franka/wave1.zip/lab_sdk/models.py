"""One controlled model request over the host's observation-bound gateway."""
import http.client
import json
import math
import os
import socket
import uuid


class ModelError(RuntimeError):
    pass


class ModelClient:
    def __init__(self, *, unix_socket=None, token=None):
        self.socket = unix_socket or os.environ.get('LAB_MODEL_SOCKET')
        self.token = token or os.environ.get('LAB_MODEL_TOKEN')
        if not self.socket or not self.token:
            raise ModelError('controlled model runtime is not configured')

    def infer(self, prompt, observation, *, model, images=(), proprio=True,
              max_output_tokens=256, deadline_ms=30000, request_id=None,
              messages=None, temperature=None, top_p=None):
        context = observation.get('model_context', {})
        observation_id = context.get('observation_id')
        if not isinstance(observation_id, str) or not observation_id:
            raise ModelError('observation has no host model binding; model runtime is not enabled')
        if not isinstance(prompt, str) or not 1 <= len(prompt.encode('utf-8')) <= 32768 or not isinstance(model, str) or not model:
            raise ValueError('prompt must be 1..32768 UTF-8 bytes and model must be named')
        if (not isinstance(images, (tuple, list)) or len(images) > 6 or any(not isinstance(x, str) for x in images)
                or len(set(images)) != len(images) or set(images)-set(observation.get('images', {}))):
            raise ValueError('images must select unique camera IDs from this public observation')
        if type(proprio) is not bool or type(max_output_tokens) is not int or not 1 <= max_output_tokens <= 2048:
            raise ValueError('invalid model budget')
        if type(deadline_ms) is not int or not 1 <= deadline_ms <= 60000:
            raise ValueError('invalid deadline')
        request_id = request_id or str(uuid.uuid4())
        try:
            if str(uuid.UUID(request_id)) != request_id:
                raise ValueError('noncanonical UUID')
        except (ValueError, TypeError, AttributeError):
            raise ValueError('request_id must be a UUID') from None
        value = {'schema': 'lab-model-request/v1', 'request_id': request_id, 'model': model,
                 'prompt': prompt, 'observation_id': observation_id, 'images': list(images),
                 'proprio': proprio, 'max_output_tokens': max_output_tokens, 'deadline_ms': deadline_ms}
        if messages is not None:
            if not isinstance(messages, list) or len(messages) > 32:
                raise ValueError('messages must be at most 32 text turns')
            for message in messages:
                if (not isinstance(message, dict) or set(message) != {'role', 'content'}
                        or message['role'] not in ('system', 'user', 'assistant')
                        or not isinstance(message['content'], str)):
                    raise ValueError('messages support text roles only')
            value['messages'] = messages
        serialized_messages = json.dumps(messages or [], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        if len(serialized_messages) + len(prompt.encode('utf-8')) > 32768:
            raise ValueError('prompt and serialized message history exceed UTF-8 budget')
        for key, option in (('temperature', temperature), ('top_p', top_p)):
            if option is not None:
                if type(option) not in (int, float) or not math.isfinite(option) or not (0 <= option <= 2 if key == 'temperature' else 0 < option <= 1):
                    raise ValueError('invalid sampling option')
                value[key] = option
        body = json.dumps(value, allow_nan=False, separators=(',', ':')).encode()
        connection = http.client.HTTPConnection('localhost', timeout=deadline_ms/1000 + 5)
        connection.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.sock.settimeout(deadline_ms/1000 + 5)
        try:
            connection.sock.connect(self.socket)
            connection.request('POST', '/v1/infer', body, {'Content-Type': 'application/json',
                               'Authorization': 'Bearer '+self.token})
            response = connection.getresponse()
            raw = response.read(4*1024*1024 + 1)
            if len(raw) > 4*1024*1024:
                raise ModelError('model response exceeds size limit')
            try:
                result = json.loads(raw)
            except (ValueError, UnicodeDecodeError):
                raise ModelError('invalid model gateway JSON') from None
            if response.status >= 400:
                raise ModelError('model gateway rejected request: HTTP '+str(response.status))
            if (not isinstance(result, dict) or result.get('schema') != 'lab-model-result/v1'
                    or any(result.get(k) != value[k] for k in ('request_id', 'model', 'observation_id'))
                    or type(result.get('ok')) is not bool):
                raise ModelError('model response identity mismatch')
            return result
        except (OSError, http.client.HTTPException):
            raise ModelError('model outcome unknown after transport failure; no automatic retry') from None
        finally:
            connection.close()

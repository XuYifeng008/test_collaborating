"""Normalize public contracts while retaining each backend's native clock."""
from copy import deepcopy
import math
import re


class ContractError(ValueError):
    pass


def _number(value):
    return type(value) in (int, float) and math.isfinite(value)


def canonical_robot(value):
    if value == 'franka':
        return value
    if value in ('dual_piper', 'piper-dual'):
        return 'piper-dual'
    raise ContractError('unsupported robot profile')


class Adapter:
    def __init__(self, instruction, *, wave=None, robot=None):
        schema = instruction.get('schema')
        inferred = {'lab-agent/v0.3': 'wave1', 'liquid-bench/v0.2': 'wave2'}.get(schema)
        if inferred is None or (wave is not None and wave != inferred):
            raise ContractError('unsupported or mismatched backend instruction')
        self.wave = inferred
        self.robot = canonical_robot(instruction.get('robot_profile'))
        if robot is not None and robot != self.robot:
            raise ContractError('assigned robot differs from package')
        self.task = instruction['task_id']
        self.arm_map = ({'arm': 'arm'} if self.robot == 'franka' else
                        {'left': 'left', 'right': 'right'} if self.wave == 'wave1' else
                        {'arm': 'left', 'right': 'right'})
        self.reverse = {v: k for k, v in self.arm_map.items()}
        self._native = deepcopy(instruction)
        if self.wave == 'wave1':
            raw_arms = instruction['arms']
            kin = instruction['robot_kinematics']
            dt = instruction['budget']['physics_dt_s']
            finish = instruction['action_contract']['finish']
            match = re.fullmatch(r'hold current robot targets for (\d+) real physics steps, then end episode', finish)
            if not match:
                raise ContractError('unknown wave1 finish semantics')
            self.finish_steps = int(match[1])
        else:
            raw_arms = instruction['actions']['arms']
            kin = instruction.get('robot_kinematics_by_arm')
            if kin is None:
                kin = instruction['robot_kinematics']
                if self.robot == 'franka':
                    kin = {'arm': kin}
            dt = instruction['physics']['step_seconds']
            self.finish_steps = instruction.get('evaluation_contract', {}).get('finish_extra_physics_steps', 0)
            if self.finish_steps != 0:
                raise ContractError('unknown wave2 finish semantics')
        if not _number(dt) or dt <= 0:
            raise ContractError('invalid physics step')
        self.dt = dt
        if set(raw_arms) != set(self.arm_map) or set(kin) != set(self.arm_map):
            raise ContractError('unexpected arm set')
        self.arms = {}
        for native, item in raw_arms.items():
            names = item.get('arm_joint_names', item.get('joint_names'))
            count = 7 if self.robot == 'franka' else 6
            if not isinstance(names, list) or len(names) != count or len(set(names)) != count:
                raise ContractError('unexpected arm joint names')
            # The model's physical stroke can exceed the public command limit.
            # In particular, wave1 PiPER advertises a 0.10 m model but a 0.08 m API.
            width = (item['gripper_max_width_m'] if self.wave == 'wave1'
                     else item['gripper_width_m'][1])
            if not _number(width) or width <= 0:
                raise ContractError('invalid gripper range')
            self.arms[self.arm_map[native]] = dict(joint_names=deepcopy(names), joint_position_count=count,
                                                   position_unit='rad', gripper_width_m=[0.0, width])
        self.kinematics = {self.arm_map[k]: deepcopy(v) for k, v in kin.items()}

    def instruction(self):
        raw = self._native
        # These fields already belong to the backend's public instruction.
        keys = ('task_id', 'instruction', 'benchmark_id', 'platform', 'initial_state',
                'task_geometry_manual', 'target_object_ids', 'bottle_identification',
                'receiving_regions', 'sensors', 'visual_measurement', 'process_parameters',
                'balance_access', 'instruments', 'scope', 'evaluation_contract', 'runtime_context')
        result = {k: deepcopy(raw[k]) for k in keys if k in raw}
        result.update(schema='lab-instruction/v2', backend_wave=self.wave,
                      backend_schema=raw['schema'], robot_profile=self.robot,
                      arms=deepcopy(self.arms), robot_kinematics=deepcopy(self.kinematics),
                      physics={'step_seconds': self.dt, 'frequency_hz': 1/self.dt,
                               'maximum_steps_per_action': 120},
                      finish={'extra_physics_steps': self.finish_steps,
                              'behavior': 'native backend finish; SDK adds no steps'},
                      actions={'arms': deepcopy(self.arms), 'maximum_steps': 120})
        if 'budget' in raw:
            result['budget'] = deepcopy(raw['budget'])
        return result

    def observation(self, raw):
        if not _number(raw.get('simulation_time_s')):
            raise ContractError('observation lacks finite simulation time')
        proprio = raw.get('proprioception')
        if not isinstance(proprio, dict) or set(proprio) != set(self.arm_map):
            raise ContractError('unexpected observation arm set')
        result = {'schema': 'lab-observation/v2', 'backend_wave': self.wave,
                  'robot_profile': self.robot, 'task_id': self.task,
                  'simulation_time_s': raw['simulation_time_s'],
                  'proprioception': {self.arm_map[k]: deepcopy(v) for k, v in proprio.items()}}
        for key in ('images', 'last_instrument_result', 'model_context', 'budget', 'evaluation', 'feedback_mode'):
            if key in raw:
                result[key] = deepcopy(raw[key])
        result['finished'] = bool(raw.get('budget', {}).get('finished', False) if self.wave == 'wave1'
                                  else raw.get('evaluation', {}).get('finished', False))
        if self.wave == 'wave1':
            if 'instruments' in raw:
                result['instruments'] = deepcopy(raw['instruments'])
        elif self.task not in ('C02', 'C07') and 'instruments' in raw:
            # Preserve the existing public volume-feedback contract only.
            allowed = ('time_s', 'task', 'source_volume_ml', 'receiver_volume_ml', 'funnel_volume_ml', 'flow_ml_s')
            result['instruments'] = {k: deepcopy(v) for k, v in raw['instruments'].items() if k in allowed}
        return result

    def action(self, action):
        if isinstance(action, dict) and set(action) == {'finish'} and action['finish'] is True:
            return {'finish': True}
        if not isinstance(action, dict):
            raise ContractError('action must be a dictionary')
        if set(action) == {'instrument'}:
            command = action['instrument']
            if (self.wave != 'wave2' or self.task != 'C07' or not isinstance(command, dict)
                    or set(command) != {'device', 'method'} or command['device'] != 'competition_balance'
                    or command['method'] not in ('read', 'tare')):
                raise ContractError('only C07 normal competition_balance read/tare is available')
            return deepcopy(action)
        if set(action) - {'arms', 'steps'}:
            raise ContractError('unknown action fields')
        steps = action.get('steps', 1)
        if type(steps) is not int or not 1 <= steps <= 120:
            raise ContractError('steps must be an integer in 1..120')
        arms = action.get('arms', {})
        if not isinstance(arms, dict):
            raise ContractError('arms must be a mapping')
        converted = {}
        for name, command in arms.items():
            if name not in self.reverse or not isinstance(command, dict) or set(command) - {'positions', 'gripper_width_m'}:
                raise ContractError('unknown arm or command fields')
            spec = self.arms[name]
            if 'positions' in command:
                q = command['positions']
                if not isinstance(q, (list, tuple)) or len(q) != spec['joint_position_count'] or not all(_number(x) for x in q):
                    raise ContractError('wrong joint count or nonfinite command')
                model = self.kinematics[name]
                limits = model.get('limits', {})
                for joint, value in zip(spec['joint_names'], q):
                    if joint in limits and not limits[joint][0]-1e-8 <= value <= limits[joint][1]+1e-8:
                        raise ContractError('joint command exceeds advertised limits')
            if 'gripper_width_m' in command:
                width = command['gripper_width_m']
                if not _number(width) or not 0 <= width <= spec['gripper_width_m'][1]:
                    raise ContractError('gripper command outside advertised range')
            converted[self.reverse[name]] = deepcopy(command)
        return {'arms': converted, 'steps': steps}

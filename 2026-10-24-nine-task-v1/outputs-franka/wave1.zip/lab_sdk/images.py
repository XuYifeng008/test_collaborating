"""Decode only supplied public camera payloads; no file/network lookup."""
import base64
import io

MAX_PNG_BYTES = 16 * 1024 * 1024
MAX_PIXELS = 16 * 1024 * 1024


def png_bytes(image):
    if not isinstance(image, dict) or image.get('mime_type') != 'image/png':
        raise ValueError('expected public image/png payload')
    encoded = image.get('base64')
    if not isinstance(encoded, str) or len(encoded) > (MAX_PNG_BYTES + 2)//3*4:
        raise ValueError('invalid or oversized PNG base64')
    try:
        data = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError('invalid PNG base64') from exc
    if len(data) > MAX_PNG_BYTES or not data.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('invalid or oversized PNG')
    return data


def pillow_rgb(image):
    from PIL import Image
    value = Image.open(io.BytesIO(png_bytes(image)))
    if value.format != 'PNG' or value.width*value.height > MAX_PIXELS:
        raise ValueError('unsupported image or pixel limit exceeded')
    value.load()
    return value.convert('RGB')


def numpy_rgb(image):
    import numpy as np
    return np.asarray(pillow_rgb(image)).copy()


def opencv_bgr(image):
    import cv2
    # Pillow validates dimensions before OpenCV receives any decoded pixels.
    return cv2.cvtColor(numpy_rgb(image), cv2.COLOR_RGB2BGR)


def camera_rgb(observation, camera_id):
    return numpy_rgb(observation['images'][camera_id])

"""Canonical facade over the platform-injected public Unix-socket SDK."""
import os
from .adapters import Adapter


class AgentClient:
    def __init__(self, transport=None, *, wave=None, robot=None):
        if transport is None:
            if not os.environ.get('LAB_AGENT_UNIX_SOCKET'):
                raise RuntimeError('LAB_AGENT_UNIX_SOCKET is required; no network fallback')
            from lab_platform.client import LabClient
            transport = LabClient(unix_socket=os.environ['LAB_AGENT_UNIX_SOCKET'])
        self.transport, self.wave, self.robot = transport, wave, robot
        self.adapter = None
        self.last_instrument_result = None

    def get_instruction(self):
        raw = self.transport.get_instruction()
        self.adapter = Adapter(raw, wave=self.wave, robot=self.robot)
        return self.adapter.instruction()

    def _ready(self):
        if self.adapter is None:
            raise RuntimeError('get_instruction must be called first')
        return self.adapter

    def get_observation(self, images=True):
        result = self._ready().observation(self.transport.get_observation(images=images))
        if self.last_instrument_result is not None:
            result['last_instrument_result'] = self.last_instrument_result
        return result

    def step(self, arms=None, steps=1, *, request_id=None):
        action = self._ready().action({'arms': arms or {}, 'steps': steps})
        return self.adapter.observation(self.transport.request('/step', action, request_id))

    def finish(self, *, request_id=None):
        self._ready()
        # Never insert a settling step: wave1 and wave2 have different finish contracts.
        return self.transport.finish(request_id=request_id)

    def instrument(self, method, *, device='competition_balance', request_id=None):
        action = self._ready().action({'instrument': {'device': device, 'method': method}})
        self.last_instrument_result = self.transport.request('/instrument', action['instrument'], request_id)
        return self.last_instrument_result

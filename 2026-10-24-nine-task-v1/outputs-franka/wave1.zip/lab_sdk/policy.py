"""Compatibility entrypoint: translates a public v1 episode to canonical Policy."""
import importlib.util
import json
from pathlib import Path
import sys
from .adapters import Adapter, ContractError


def require_runtime(raw, manifest):
    context = raw.get('runtime_context', {})
    for key in ('runtime_profile_sha256', 'configuration_sha256'):
        if context.get(key) != manifest[key]:
            raise ContractError('model/image runtime identity not enabled or mismatched: '+key)
    if context.get('model_api', {}).get('enabled') is not True:
        raise ContractError('controlled model API is required by this runtime')
    if not {'numpy', 'Pillow', 'opencv-python-headless'} <= set(context.get('image_dependencies', [])):
        raise ContractError('required image dependencies are not advertised')


def make_policy(wrapper_file, wave, robot):
    root = Path(wrapper_file).resolve().parent
    manifest = json.loads((root/'submission.json').read_text())
    canonical = root/'canonical'
    original = json.loads((canonical/'submission.json').read_text())
    target = (canonical/original['entrypoint']).resolve()
    if canonical not in target.parents or target.suffix != '.py':
        raise ContractError('invalid canonical entrypoint')

    class WrappedPolicy:
        def reset(self, raw):
            require_runtime(raw, manifest)
            self.adapter = Adapter(raw, wave=wave, robot=robot)
            name = '_lab_canonical_policy'
            spec = importlib.util.spec_from_file_location(name, target)
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            # Required for ordinary user helper modules; no organizer imports.
            sys.path[:0] = list(dict.fromkeys((str(target.parent), str(canonical))))
            spec.loader.exec_module(module)
            self.policy = module.Policy()
            self.policy.reset(self.adapter.instruction())
            self.observation_images = getattr(self.policy, 'observation_images', True)

        def act(self, raw):
            return self.adapter.action(self.policy.act(self.adapter.observation(raw)))

    return WrappedPolicy
